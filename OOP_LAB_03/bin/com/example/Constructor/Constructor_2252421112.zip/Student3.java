package com.example.Constructor;

public class Student3 {
	
	int id;
	String name;
	
	void display() {
		System.out.println(id+" "+name);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student3 s1=new Student3();
		Student3 s2=new Student3();
		
		s1.display();
		s2.display();

	}

}
