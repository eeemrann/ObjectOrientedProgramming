//Write a Java problem called person with name and age attribute. 
//Create two instances of person class. 
//Print the name and age attribute.


package com.example.Constructor;

public class Person {
	private String name;
	private int age;
	
	public Person(String n,int a) {
		name=n;
		age=a;
	}
	
	public String getName() {
		return name;
	}
	
	public int getAge() {
		return age;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Person p1=new Person("Emran",12);
		Person p2=new Person("Mahdi",11);
		
		System.out.println(p1.getName()+" is "+p1.getAge()+" years old.");
		System.out.println(p2.getName()+" is "+p2.getAge()+" years old.");

	}

}
